Low-poly male and female base-meshes, version 1.2 (30th of March, 2012)

Version history: 1.2 significantly updated the female mesh, similar changes to the male will follow.

(c) Julius Krischan Makowka

Contact: jkmakowka@yahoo.de

License: 
These meshes can be used and modified under the terms of the "GPL version 2 (or later)" and/or the "Creative Commons Attribution Share-Alike 3.0 (or later)" license.

Other more liberal licensing options might be negotiable on request.

It would be nice if you could also link to www.opengameart.org
